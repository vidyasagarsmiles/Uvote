package ibmmobileappbuilder.mvp.model;

public interface IdProvider {
    String identifier();
}
