

package com.ibm.mobileappbuilder.uvote20161026214320.ui;

import android.os.Bundle;
import android.support.v4.app.Fragment;

import ibmmobileappbuilder.ui.BaseDetailActivity;

/**
 * ParticipantslistScreen1DetailActivity detail activity
 */
public class ParticipantslistScreen1DetailActivity extends BaseDetailActivity {
  
  	@Override
    protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    @Override
    protected Class<? extends Fragment> getFragmentClass() {
        return ParticipantslistScreen1DetailFragment.class;
    }
}


