
package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class RegistrationDSSchemaItem implements Parcelable, IdentifiableBean {

    @SerializedName("id") public String id;
    @SerializedName("firstName") public String firstName;
    @SerializedName("lastName") public String lastName;
    @SerializedName("dataField0") public String dataField0;
    @SerializedName("uploadYourImage") public Integer uploadYourImage;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(firstName);
        dest.writeString(lastName);
        dest.writeString(dataField0);
        dest.writeValue(uploadYourImage);
    }

    public static final Creator<RegistrationDSSchemaItem> CREATOR = new Creator<RegistrationDSSchemaItem>() {
        @Override
        public RegistrationDSSchemaItem createFromParcel(Parcel in) {
            RegistrationDSSchemaItem item = new RegistrationDSSchemaItem();

            item.id = in.readString();
            item.firstName = in.readString();
            item.lastName = in.readString();
            item.dataField0 = in.readString();
            item.uploadYourImage = (Integer) in.readValue(null);
            return item;
        }

        @Override
        public RegistrationDSSchemaItem[] newArray(int size) {
            return new RegistrationDSSchemaItem[size];
        }
    };

}


