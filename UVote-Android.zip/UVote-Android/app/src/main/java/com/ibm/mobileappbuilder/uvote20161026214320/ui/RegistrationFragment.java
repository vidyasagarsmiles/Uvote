
package com.ibm.mobileappbuilder.uvote20161026214320.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.ibm.mobileappbuilder.uvote20161026214320.R;
import ibmmobileappbuilder.ds.Datasource;
import android.widget.ImageView;
import android.widget.TextView;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.uvote20161026214320.ds.RegistrationDSSchemaItem;
import com.ibm.mobileappbuilder.uvote20161026214320.ds.RegistrationDS;

public class RegistrationFragment extends ibmmobileappbuilder.ui.DetailFragment<RegistrationDSSchemaItem>  {

    private Datasource<RegistrationDSSchemaItem> datasource;
    private SearchOptions searchOptions;

    public static RegistrationFragment newInstance(Bundle args){
        RegistrationFragment card = new RegistrationFragment();
        card.setArguments(args);

        return card;
    }

    public RegistrationFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
      if (datasource != null) {
          return datasource;
      }
          datasource = RegistrationDS.getInstance(searchOptions);
          return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.registration_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final RegistrationDSSchemaItem item, View view) {
        if (item.firstName != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.firstName);
            
        }
        if (item.lastName != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.lastName);
            
        }
        if (item.dataField0 != null){
            
            TextView view2 = (TextView) view.findViewById(R.id.view2);
            view2.setText(item.dataField0);
            
        }
        
        if(item.uploadYourImage != null){
            ImageView view3 = (ImageView) view.findViewById(R.id.view3);
            ImageLoader imageLoader = new PicassoImageLoader(view.getContext());
            imageLoader.load(imageLoaderRequest()
                            .withResourceToLoad(item.uploadYourImage)
                            .withTargetView(view3)
                            .build()
            );
            
        }
    }

    @Override
    protected void onShow(RegistrationDSSchemaItem item) {
        // set the title for this fragment
        getActivity().setTitle("Registration");
    }

}

