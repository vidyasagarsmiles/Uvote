

package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.uvote20161026214320.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// ParticipantDetailsDSSchemaItem static data
public class ParticipantDetailsDSItems{

    public static List<ParticipantDetailsDSSchemaItem> ITEMS = new ArrayList<ParticipantDetailsDSSchemaItem>();
    public static void addItem(ParticipantDetailsDSSchemaItem item) {
        ITEMS.add(item);
    }
}


