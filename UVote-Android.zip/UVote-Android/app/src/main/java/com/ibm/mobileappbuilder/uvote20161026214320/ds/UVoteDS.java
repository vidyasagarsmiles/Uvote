
package com.ibm.mobileappbuilder.uvote20161026214320.ds;

import ibmmobileappbuilder.ds.Count;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.Distinct;
import ibmmobileappbuilder.ds.Pagination;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import ibmmobileappbuilder.util.FilterUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * "UVoteDS" static data source (49cf47ba-2673-4db8-bc7b-bdd8158932b1)
 */
public class UVoteDS implements Datasource<UVoteDSSchemaItem>, Count,
            Pagination<UVoteDSSchemaItem>, Distinct {

    private static final int PAGE_SIZE = 20;

    private SearchOptions searchOptions;

    public static UVoteDS getInstance(SearchOptions searchOptions){
        return new UVoteDS(searchOptions);
    }

    private UVoteDS(SearchOptions searchOptions){
        this.searchOptions = searchOptions;
    }

    @Override
    public void getItems(Listener<List<UVoteDSSchemaItem>> listener) {
        listener.onSuccess(UVoteDSItems.ITEMS);
    }

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getItem(String id, Listener<UVoteDSSchemaItem> listener) {
        final int pos = Integer.parseInt(id);
        if(UVoteDSItems.ITEMS.size() <= pos){
        	listener.onSuccess(new UVoteDSSchemaItem());
        }
        else {
	        UVoteDSSchemaItem dc = UVoteDSItems.ITEMS.get(pos);
	        if( dc != null)
	            listener.onSuccess(dc);
	        else
	            listener.onFailure(new IllegalArgumentException("UVoteDSSchemaItem not found: " + pos));
	    }
    }

    @Override public int getCount(){
        return UVoteDSItems.ITEMS.size();
    }

    @Override
    public void getItems(int pagenum, Listener<List<UVoteDSSchemaItem>> listener) {
        int first = pagenum * PAGE_SIZE;
        int last = first + PAGE_SIZE;
        ArrayList<UVoteDSSchemaItem> result = new ArrayList<UVoteDSSchemaItem>();
        List<UVoteDSSchemaItem> filteredList = applySearchOptions(UVoteDSItems.ITEMS);
        if(first < filteredList.size())
            for (int i = first; (i < last) && (i < filteredList.size()); i++)
                result.add(filteredList.get(i));

        listener.onSuccess(result);
    }

    @Override
    public void onSearchTextChanged(String s){
        searchOptions.setSearchText(s);
    }

    @Override
    public void addFilter(Filter filter){
        searchOptions.addFilter(filter);
    }

    @Override
    public void clearFilters() {
        searchOptions.setFilters(null);
    }

    private List<UVoteDSSchemaItem> applySearchOptions(List<UVoteDSSchemaItem> result) {
        List<UVoteDSSchemaItem> filteredList = result;

        //Searching options
        String searchText = searchOptions.getSearchText();

        if(searchOptions.getFixedFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFixedFilters());

        if(searchOptions.getFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFilters());

        if (searchText != null && !"".equals(searchText))
            filteredList = applySearch(filteredList, searchText);

        //Sorting options
        Comparator comparator = searchOptions.getSortComparator();
        if (comparator != null) {
            if (searchOptions.isSortAscending()) {
                Collections.sort(filteredList, comparator);
            } else {
                Collections.sort(filteredList, Collections.reverseOrder(comparator));
            }
        }

        return filteredList;
    }

    private List<UVoteDSSchemaItem> applySearch(List<UVoteDSSchemaItem> items, String searchText) {
        List<UVoteDSSchemaItem> filteredList = new ArrayList<>();

        for (UVoteDSSchemaItem item : items) {
                        
            if (FilterUtils.searchInString(item.id, searchText) ||
            FilterUtils.searchInString(item.userid, searchText) ||
            FilterUtils.searchInString(item.password, searchText))
            {
                filteredList.add(item);
            }
        }

        return filteredList;

    }

    private List<UVoteDSSchemaItem> applyFilters(List<UVoteDSSchemaItem> items, List<Filter> filters) {
        List<UVoteDSSchemaItem> filteredList = new ArrayList<>();

        for (UVoteDSSchemaItem item : items) {
            if (
                FilterUtils.applyFilters("id", item.id, filters) &&
                FilterUtils.applyFilters("logo", item.logo, filters) &&
                FilterUtils.applyFilters("userid", item.userid, filters) &&
                FilterUtils.applyFilters("password", item.password, filters)
                ){

                filteredList.add(item);
            }
        }

        return filteredList;
    }

    // Distinct interface

    @Override
    public void getUniqueValuesFor(String columnName, Listener<List<String>> listener) {
        List<UVoteDSSchemaItem> filteredList = applySearchOptions(UVoteDSItems.ITEMS);
        listener.onSuccess(mapItems(filteredList, columnName));
    }

    private List<String> mapItems(List<UVoteDSSchemaItem> items, String columnName){
        // return only unique values
        ArrayList<String> res = new ArrayList();
        for (UVoteDSSchemaItem item: items){
            String mapped = mapItem(item, columnName);
            if(mapped != null && !res.contains(mapped))
                res.add(mapped);
        }

        return res;
    }

    private String mapItem(UVoteDSSchemaItem item, String columnName){
        // get fields
        switch (columnName){
                        
            case "id":
                return item.id;
            
            case "userid":
                return item.userid;
            
            case "password":
                return item.password;
            default:
               return null;
        }
    }
}


