

package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.uvote20161026214320.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// UVoteDSSchemaItem static data
public class UVoteDSItems{

    public static List<UVoteDSSchemaItem> ITEMS = new ArrayList<UVoteDSSchemaItem>();
    static {
        // Add items.
        UVoteDSSchemaItem item;
        item = new UVoteDSSchemaItem();
        item.logo = R.drawable.png_logodefault;
        item.id = "5811299ab80ceb0300543f7d";
        addItem(item);
    }
    public static void addItem(UVoteDSSchemaItem item) {
        ITEMS.add(item);
    }
}


