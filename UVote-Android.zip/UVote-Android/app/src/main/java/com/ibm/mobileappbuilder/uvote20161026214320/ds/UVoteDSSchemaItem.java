
package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class UVoteDSSchemaItem implements Parcelable, IdentifiableBean {

    @SerializedName("id") public String id;
    @SerializedName("logo") public Integer logo;
    @SerializedName("userid") public String userid;
    @SerializedName("password") public String password;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeValue(logo);
        dest.writeString(userid);
        dest.writeString(password);
    }

    public static final Creator<UVoteDSSchemaItem> CREATOR = new Creator<UVoteDSSchemaItem>() {
        @Override
        public UVoteDSSchemaItem createFromParcel(Parcel in) {
            UVoteDSSchemaItem item = new UVoteDSSchemaItem();

            item.id = in.readString();
            item.logo = (Integer) in.readValue(null);
            item.userid = in.readString();
            item.password = in.readString();
            return item;
        }

        @Override
        public UVoteDSSchemaItem[] newArray(int size) {
            return new UVoteDSSchemaItem[size];
        }
    };

}


