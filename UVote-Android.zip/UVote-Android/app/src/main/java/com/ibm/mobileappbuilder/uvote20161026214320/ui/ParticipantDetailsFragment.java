
package com.ibm.mobileappbuilder.uvote20161026214320.ui;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import com.ibm.mobileappbuilder.uvote20161026214320.R;
import ibmmobileappbuilder.ds.Datasource;
import android.widget.ImageView;
import android.widget.TextView;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.uvote20161026214320.ds.ParticipantslistDSSchemaItem;
import com.ibm.mobileappbuilder.uvote20161026214320.ds.ParticipantslistDS;

public class ParticipantDetailsFragment extends ibmmobileappbuilder.ui.DetailFragment<ParticipantslistDSSchemaItem>  {

    private Datasource<ParticipantslistDSSchemaItem> datasource;
    private SearchOptions searchOptions;

    public static ParticipantDetailsFragment newInstance(Bundle args){
        ParticipantDetailsFragment card = new ParticipantDetailsFragment();
        card.setArguments(args);

        return card;
    }

    public ParticipantDetailsFragment(){
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
            searchOptions = SearchOptions.Builder.searchOptions().build();
    }

    @Override
    public Datasource getDatasource() {
      if (datasource != null) {
          return datasource;
      }
          datasource = ParticipantslistDS.getInstance(searchOptions);
          return datasource;
    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.participantdetails_custom;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ParticipantslistDSSchemaItem item, View view) {
        if (item.screenName != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.screenName);
            
        }
        if (item.dataField0 != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.dataField0);
            
        }
        
        if(item.picture != null){
            ImageView view2 = (ImageView) view.findViewById(R.id.view2);
            ImageLoader imageLoader = new PicassoImageLoader(view.getContext());
            imageLoader.load(imageLoaderRequest()
                            .withResourceToLoad(item.picture)
                            .withTargetView(view2)
                            .build()
            );
            
        }
    }

    @Override
    protected void onShow(ParticipantslistDSSchemaItem item) {
        // set the title for this fragment
        getActivity().setTitle("Participant Details");
    }

}

