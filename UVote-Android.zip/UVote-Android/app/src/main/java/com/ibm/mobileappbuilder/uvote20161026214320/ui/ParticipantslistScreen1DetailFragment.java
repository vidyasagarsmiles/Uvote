
package com.ibm.mobileappbuilder.uvote20161026214320.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import com.ibm.mobileappbuilder.uvote20161026214320.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.util.image.ImageLoader;
import ibmmobileappbuilder.util.image.PicassoImageLoader;
import static ibmmobileappbuilder.util.image.ImageLoaderRequest.Builder.imageLoaderRequest;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.uvote20161026214320.ds.ParticipantslistDSSchemaItem;
import com.ibm.mobileappbuilder.uvote20161026214320.ds.ParticipantslistDS;

public class ParticipantslistScreen1DetailFragment extends ibmmobileappbuilder.ui.DetailFragment<ParticipantslistDSSchemaItem> implements ShareBehavior.ShareListener  {

    private Datasource<ParticipantslistDSSchemaItem> datasource;
    public static ParticipantslistScreen1DetailFragment newInstance(Bundle args){
        ParticipantslistScreen1DetailFragment fr = new ParticipantslistScreen1DetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public ParticipantslistScreen1DetailFragment(){
        super();
    }

    @Override
    public Datasource<ParticipantslistDSSchemaItem> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = ParticipantslistDS.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.participantslistscreen1detail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final ParticipantslistDSSchemaItem item, View view) {
        if (item.screenName != null){
            
            TextView view0 = (TextView) view.findViewById(R.id.view0);
            view0.setText(item.screenName);
            
        }
        if (item.dataField0 != null){
            
            TextView view1 = (TextView) view.findViewById(R.id.view1);
            view1.setText(item.dataField0);
            
        }
        
        if(item.picture != null){
            ImageView view2 = (ImageView) view.findViewById(R.id.view2);
            ImageLoader imageLoader = new PicassoImageLoader(view.getContext());
            imageLoader.load(imageLoaderRequest()
                            .withResourceToLoad(item.picture)
                            .withTargetView(view2)
                            .build()
            );
            
        }
    }

    @Override
    protected void onShow(ParticipantslistDSSchemaItem item) {
        // set the title for this fragment
        getActivity().setTitle(null);
    }
    @Override
    public void onShare() {
        ParticipantslistDSSchemaItem item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, (item.screenName != null ? item.screenName : "" ) + "\n" +
                    (item.dataField0 != null ? item.dataField0 : "" ));
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

