
package com.ibm.mobileappbuilder.uvote20161026214320.ds;

import ibmmobileappbuilder.ds.Count;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.ds.Distinct;
import ibmmobileappbuilder.ds.Pagination;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import ibmmobileappbuilder.util.FilterUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * "ParticipantslistDS" static data source (5e151ff1-fcac-44da-8568-e39e45479c6c)
 */
public class ParticipantslistDS implements Datasource<ParticipantslistDSSchemaItem>, Count,
            Pagination<ParticipantslistDSSchemaItem>, Distinct {

    private static final int PAGE_SIZE = 20;

    private SearchOptions searchOptions;

    public static ParticipantslistDS getInstance(SearchOptions searchOptions){
        return new ParticipantslistDS(searchOptions);
    }

    private ParticipantslistDS(SearchOptions searchOptions){
        this.searchOptions = searchOptions;
    }

    @Override
    public void getItems(Listener<List<ParticipantslistDSSchemaItem>> listener) {
        listener.onSuccess(ParticipantslistDSItems.ITEMS);
    }

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getItem(String id, Listener<ParticipantslistDSSchemaItem> listener) {
        final int pos = Integer.parseInt(id);
        if(ParticipantslistDSItems.ITEMS.size() <= pos){
        	listener.onSuccess(new ParticipantslistDSSchemaItem());
        }
        else {
	        ParticipantslistDSSchemaItem dc = ParticipantslistDSItems.ITEMS.get(pos);
	        if( dc != null)
	            listener.onSuccess(dc);
	        else
	            listener.onFailure(new IllegalArgumentException("ParticipantslistDSSchemaItem not found: " + pos));
	    }
    }

    @Override public int getCount(){
        return ParticipantslistDSItems.ITEMS.size();
    }

    @Override
    public void getItems(int pagenum, Listener<List<ParticipantslistDSSchemaItem>> listener) {
        int first = pagenum * PAGE_SIZE;
        int last = first + PAGE_SIZE;
        ArrayList<ParticipantslistDSSchemaItem> result = new ArrayList<ParticipantslistDSSchemaItem>();
        List<ParticipantslistDSSchemaItem> filteredList = applySearchOptions(ParticipantslistDSItems.ITEMS);
        if(first < filteredList.size())
            for (int i = first; (i < last) && (i < filteredList.size()); i++)
                result.add(filteredList.get(i));

        listener.onSuccess(result);
    }

    @Override
    public void onSearchTextChanged(String s){
        searchOptions.setSearchText(s);
    }

    @Override
    public void addFilter(Filter filter){
        searchOptions.addFilter(filter);
    }

    @Override
    public void clearFilters() {
        searchOptions.setFilters(null);
    }

    private List<ParticipantslistDSSchemaItem> applySearchOptions(List<ParticipantslistDSSchemaItem> result) {
        List<ParticipantslistDSSchemaItem> filteredList = result;

        //Searching options
        String searchText = searchOptions.getSearchText();

        if(searchOptions.getFixedFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFixedFilters());

        if(searchOptions.getFilters() != null)
            filteredList = applyFilters(filteredList, searchOptions.getFilters());

        if (searchText != null && !"".equals(searchText))
            filteredList = applySearch(filteredList, searchText);

        //Sorting options
        Comparator comparator = searchOptions.getSortComparator();
        if (comparator != null) {
            if (searchOptions.isSortAscending()) {
                Collections.sort(filteredList, comparator);
            } else {
                Collections.sort(filteredList, Collections.reverseOrder(comparator));
            }
        }

        return filteredList;
    }

    private List<ParticipantslistDSSchemaItem> applySearch(List<ParticipantslistDSSchemaItem> items, String searchText) {
        List<ParticipantslistDSSchemaItem> filteredList = new ArrayList<>();

        for (ParticipantslistDSSchemaItem item : items) {
                        
            if (FilterUtils.searchInString(item.id, searchText) ||
            FilterUtils.searchInString(item.screenName, searchText) ||
            FilterUtils.searchInString(item.dataField0, searchText))
            {
                filteredList.add(item);
            }
        }

        return filteredList;

    }

    private List<ParticipantslistDSSchemaItem> applyFilters(List<ParticipantslistDSSchemaItem> items, List<Filter> filters) {
        List<ParticipantslistDSSchemaItem> filteredList = new ArrayList<>();

        for (ParticipantslistDSSchemaItem item : items) {
            if (
                FilterUtils.applyFilters("id", item.id, filters) &&
                FilterUtils.applyFilters("screenName", item.screenName, filters) &&
                FilterUtils.applyFilters("dataField0", item.dataField0, filters) &&
                FilterUtils.applyFilters("picture", item.picture, filters)
                ){

                filteredList.add(item);
            }
        }

        return filteredList;
    }

    // Distinct interface

    @Override
    public void getUniqueValuesFor(String columnName, Listener<List<String>> listener) {
        List<ParticipantslistDSSchemaItem> filteredList = applySearchOptions(ParticipantslistDSItems.ITEMS);
        listener.onSuccess(mapItems(filteredList, columnName));
    }

    private List<String> mapItems(List<ParticipantslistDSSchemaItem> items, String columnName){
        // return only unique values
        ArrayList<String> res = new ArrayList();
        for (ParticipantslistDSSchemaItem item: items){
            String mapped = mapItem(item, columnName);
            if(mapped != null && !res.contains(mapped))
                res.add(mapped);
        }

        return res;
    }

    private String mapItem(ParticipantslistDSSchemaItem item, String columnName){
        // get fields
        switch (columnName){
                        
            case "id":
                return item.id;
            
            case "screenName":
                return item.screenName;
            
            case "dataField0":
                return item.dataField0;
            default:
               return null;
        }
    }
}


