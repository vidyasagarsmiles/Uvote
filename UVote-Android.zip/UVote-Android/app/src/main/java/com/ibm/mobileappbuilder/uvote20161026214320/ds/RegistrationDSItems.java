

package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.uvote20161026214320.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// RegistrationDSSchemaItem static data
public class RegistrationDSItems{

    public static List<RegistrationDSSchemaItem> ITEMS = new ArrayList<RegistrationDSSchemaItem>();
    static {
        // Add items.
        RegistrationDSSchemaItem item;
        item = new RegistrationDSSchemaItem();
        item.id = "5812a5aa5f442f03000c9e99";
        item.firstName = "Vidya Sagar";
        item.lastName = "Veeramallu";
        item.dataField0 = "I am from MAC";
        addItem(item);
    }
    public static void addItem(RegistrationDSSchemaItem item) {
        ITEMS.add(item);
    }
}


