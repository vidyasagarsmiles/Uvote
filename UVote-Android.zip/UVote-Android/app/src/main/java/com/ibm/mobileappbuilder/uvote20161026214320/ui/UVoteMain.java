package com.ibm.mobileappbuilder.uvote20161026214320.ui;

import android.support.v4.app.Fragment;
import android.util.SparseArray;

import ibmmobileappbuilder.ui.DrawerActivity;

import com.ibm.mobileappbuilder.uvote20161026214320.ds.ParticipantslistDSSchemaItem;
import com.ibm.mobileappbuilder.uvote20161026214320.R;

public class UVoteMain extends DrawerActivity {

    private final SparseArray<Class<? extends Fragment>> sectionFragments = new SparseArray<>();
    {
                sectionFragments.append(R.id.entry0, ParticipantslistScreen1Fragment.class);
            sectionFragments.append(R.id.entry1, ParticipantDetailsFragment.class);
            sectionFragments.append(R.id.entry2, RegistrationFragment.class);
            sectionFragments.append(R.id.entry3, LogoutFragment.class);
    }

    @Override
    public SparseArray<Class<? extends Fragment>> getSectionFragmentClasses() {
      return sectionFragments;
    }

}

