
package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ParticipantslistDSSchemaItem implements Parcelable, IdentifiableBean {

    @SerializedName("id") public String id;
    @SerializedName("screenName") public String screenName;
    @SerializedName("dataField0") public String dataField0;
    @SerializedName("picture") public Integer picture;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(screenName);
        dest.writeString(dataField0);
        dest.writeValue(picture);
    }

    public static final Creator<ParticipantslistDSSchemaItem> CREATOR = new Creator<ParticipantslistDSSchemaItem>() {
        @Override
        public ParticipantslistDSSchemaItem createFromParcel(Parcel in) {
            ParticipantslistDSSchemaItem item = new ParticipantslistDSSchemaItem();

            item.id = in.readString();
            item.screenName = in.readString();
            item.dataField0 = in.readString();
            item.picture = (Integer) in.readValue(null);
            return item;
        }

        @Override
        public ParticipantslistDSSchemaItem[] newArray(int size) {
            return new ParticipantslistDSSchemaItem[size];
        }
    };

}


