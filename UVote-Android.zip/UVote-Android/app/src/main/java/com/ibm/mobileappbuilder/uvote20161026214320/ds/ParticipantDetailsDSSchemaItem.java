
package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;

import ibmmobileappbuilder.mvp.model.IdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class ParticipantDetailsDSSchemaItem implements Parcelable, IdentifiableBean {

    @SerializedName("id") public String id;
    @SerializedName("name") public String name;
    @SerializedName("promotionDescription") public String promotionDescription;
    @SerializedName("picture") public Integer picture;

    @Override
    public String getIdentifiableId() {
      return id;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(id);
        dest.writeString(name);
        dest.writeString(promotionDescription);
        dest.writeValue(picture);
    }

    public static final Creator<ParticipantDetailsDSSchemaItem> CREATOR = new Creator<ParticipantDetailsDSSchemaItem>() {
        @Override
        public ParticipantDetailsDSSchemaItem createFromParcel(Parcel in) {
            ParticipantDetailsDSSchemaItem item = new ParticipantDetailsDSSchemaItem();

            item.id = in.readString();
            item.name = in.readString();
            item.promotionDescription = in.readString();
            item.picture = (Integer) in.readValue(null);
            return item;
        }

        @Override
        public ParticipantDetailsDSSchemaItem[] newArray(int size) {
            return new ParticipantDetailsDSSchemaItem[size];
        }
    };

}


