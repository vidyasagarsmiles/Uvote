

package com.ibm.mobileappbuilder.uvote20161026214320.ds;
import java.net.URL;
import ibmmobileappbuilder.util.StringUtils;
import com.ibm.mobileappbuilder.uvote20161026214320.R;
import java.util.ArrayList;
import java.util.List;
import ibmmobileappbuilder.util.StringUtils;

// ParticipantslistDSSchemaItem static data
public class ParticipantslistDSItems{

    public static List<ParticipantslistDSSchemaItem> ITEMS = new ArrayList<ParticipantslistDSSchemaItem>();
    static {
        // Add items.
        ParticipantslistDSSchemaItem item;
        item = new ParticipantslistDSSchemaItem();
        item.picture = R.drawable.jpg_sl0vrcdtpi;
        item.dataField0 = "I am From Mac";
        item.screenName = "Vidya Sagar";
        item.id = "581296ca5f442f03000c9e35";
        addItem(item);
        item = new ParticipantslistDSSchemaItem();
        item.picture = R.drawable.jpg_n1s4liupbq;
        item.dataField0 = "I am From Mac and Vote for me";
        item.screenName = "Sai Kiran jakka";
        item.id = "5812971de64b8f03004440e7";
        addItem(item);
        item = new ParticipantslistDSSchemaItem();
        item.picture = R.drawable.jpg_grg6am0xns;
        item.dataField0 = "I am From Mac and Vote for me";
        item.screenName = "MadhuSudhan reddy";
        item.id = "58129721e64b8f03004440e8";
        addItem(item);
        item = new ParticipantslistDSSchemaItem();
        item.picture = R.drawable.jpg_1oov6c9gzp;
        item.dataField0 = "I am From Mac and Vote for me";
        item.screenName = "Mukesh Belde";
        item.id = "5812973c5f442f03000c9e36";
        addItem(item);
    }
    public static void addItem(ParticipantslistDSSchemaItem item) {
        ITEMS.add(item);
    }
}


